clear
clc
close all
global modelAtm trackCov MassforPlot MassforPlotAlpha Struct
global Tagg CpT DpT NumConcT
global trackCondSink

trackCondSink = zeros(1,11);

modelAtm.NumBins=4;
n = modelAtm.NumBins;

%Set simulation options: 1=yes, 0 = no ----------------------------
modelAtm.AgingYN = 0; 

modelAtm.AmmonSeedYN = 0;
modelAtm.AmmonSeedYNPop2 = 1;
modelAtm.PulseYN = 1;
modelAtm.KelvinYN = 1;
modelAtm.AlphaPYN = 0; %Alpha pinene organic = 1; single-bin organic = 0;
modelAtm.AlphaPYNPop2 = 0;
modelAtm.AlphaPYNVap = 0;

%Set simulation parameters ----------------------------
TimeVector = [0 5]*3600;

EmitTime = 3*3600;
modelAtm.EmitTime = EmitTime;
modelAtm.DecayConstant = 3;     %hr-1
modelAtm.Injection = 10;        %ug/m3
modelAtm.AgingResTime = 5;      %hr  

modelAtm.BGBin = 3; %Specify C* bin of initial particles; 1 is C*=1e-2, 2 is C* =1e-1, 3 is C*=1e0, 4 is C*=1\  /X\( .. )/X\ 
modelAtm.EmitBin = 1;

SulfMassConc = 1e-2; %Sulf concentration in vapor (held constant for now)


%modelAtm.ROG = 7e-4; % reacting organic rate [=] ug/m3-s
modelAtm.ROG = 0.1e-3;
modelAtm.ROG = 7*1e-4;


DiamSusp = 200;
TotalSusp = 4;
TagSusp = 2; %1 = specify #/m3    2=specify ug/m3

TotalOnWall = 1;
TagOnWall = 1; %1 = specify #/m3    2=specify ug/m3

%LoadSOAProps(ROG, EmitTime, EmitBin);
LoadAtmos;
LoadSOAProps;
modelAtm.SOA.lambda = 100e-9;
LoadSulfProps(SulfMassConc);
LoadSuspendedPopulation(TotalSusp,TagSusp,DiamSusp);
LoadPopulationProps(1); 
modelAtm.Cv01=LoadEqmVapors2(1);
%modelAtm.Cv02=LoadEqmVapors2(2);
%modelAtm.Cv0 = modelAtm.Cv01+modelAtm.Cv02;
modelAtm.Cv0 = modelAtm.Cv01;
%LoadEqmVapors;
%%modelAtm.Cv0 = [0.028*0.01 0 0.36*1 0.61*10]*modelAtm.Pop1.Kelvin0;%% This is for testing alpha-P distribtuion
%modelAtm.Cv0 = modelAtm.Cv01+[0.028*0.01 0 0 0];
%modelAtm.Cv0 = [0.028*0.01 0 0.36*1 0.61*10];
%modelAtm.Cv0 = [0.028*0.01 0 0 0]; %Testing

%Read the ICs ---------------------------
j=1;
PopString = int2str(j);
for i =1:n
  Cp0(i) = modelAtm.Pop1.Cp0(i); 
end
Dp0(1) = modelAtm.Pop1.Dp0;
MSulf0(1) = modelAtm.Pop1.MSulf0;

%Initialize -----------------------------------
FinalTime = TimeVector(length(TimeVector));
TotalPop = length(TimeVector);
modelAtm.Pop = TotalPop;
modelAtm.total_cov = 0;
trackCov = zeros(1,4);    
modelAtm.MSOATot0 = sum(modelAtm.Pop1.Cp0)+sum(modelAtm.Cv0);

Cp0_new = eps*ones(1,n);
Yagg = [];
Tagg = [];
Cv0 = modelAtm.Cv0;

for i=1:TotalPop-1
    Pop = 1+i;
    PopString = int2str(Pop);
    
    eval(['modelAtm.Pop' PopString '.Dp0 = Dp0(1);'])
    %eval(['modelAtm.Pop' PopString '.MSulf0 = 0;'])
    
    LoadSecondPopulation(Pop,TotalOnWall,TagOnWall);
    LoadSecondPopulation(Pop,TotalOnWall,0); %Tag = 0 -> Load only one particle
    LoadPopulationProps(Pop);
   
    %eval(['NumConc = modelAtm.Pop' PopString '.NumConc0;'])
    eval(['Cp0_new = modelAtm.Pop' PopString '.Cp0;'])
    eval(['MSulf0_new = modelAtm.Pop' PopString '.MSulf0;'])
 
    Cp0 = [Cp0 Cp0_new];
    Dp0 = [Dp0 Dp0(1)];
    MSulf0 = [MSulf0 MSulf0_new];
    %NumConc0 = [NumConc0 NumConc];
    
    tspan = [TimeVector(i) TimeVector(i+1)];
    %y0=[Cv0 Cp0 Dp0 MSulf0 NumConc0];
    y0=[Cv0 Cp0 Dp0 MSulf0];
    
    [T,Y] = Main3(Pop,tspan,y0);
    
    if i==1
        Yagg = Y;
    elseif i>1
        Yagg = [Yagg zeros(length(Yagg(:,1)),n+3); Y];
    end
  
    Tagg = [Tagg; T];
    EndIndex(Pop) = length(Tagg);
    Yfinal = Yagg(length(Tagg),:);
    
    
    %Save final values of integration variables after run: these will be initial conditions
    %for the next population
    
    Cv0 = Yfinal(1:n);
    Cp0 = Yfinal((n+1):(n+n*Pop));    
    In = length(Cp0);
    for i = 1:n
        Cp0_new(i) = Cp0(In+i-5); 
    end
    Dp0 = Yfinal(n*(Pop+1)+1:n*(Pop+1)+Pop);
    MSulf0 = Yfinal(n*(Pop+1)+Pop+1:n*(Pop+1)+2*Pop);
    %NumConc0 = Yfinal(n*(Pop+1)+Pop*2+1:n*(Pop+1)+3*Pop);
    
end



%modelAtm.Dpf = Dpf;
EndIndex(1) = 0;

CpT = zeros(0,n); DpT = zeros(0,1); MSulfT = zeros(0,1); %NumConcT = zeros(0,1);

CvT = Yagg(:,(1:n));

for p = 2:TotalPop
   Cp_new = Yagg(EndIndex(p-1)+1:EndIndex(p),n+1:(p+1)*n);
   Dp_new = Yagg(EndIndex(p-1)+1:EndIndex(p), n*(p+1)+1:n*(p+1)+p);
   MSulf_new = Yagg(EndIndex(p-1)+1:EndIndex(p), n*(p+1)+p+1:n*(p+1)+2*p);
   %NumConc_new = Yagg(EndIndex(p-1)+1:EndIndex(p), n*(p+1)+2*p+1:n*(p+1)+3*p);
   
   CpT = [CpT zeros(EndIndex(p-1),n); Cp_new];
   DpT = [DpT zeros(EndIndex(p-1),1); Dp_new];
   MSulfT = [MSulfT zeros(EndIndex(p-1),1); MSulf_new];
   %NumConcT = [NumConcT zeros(EndIndex(p-1),1); NumConc_new];
end

%Check mass balance---------------------------------------------------------------------------
TotalSuspMSOA = 0;
TotalPop2MSOA = 0;
TotalVap = 0;

for j=1:n
    TotalPop2MSOA = TotalPop2MSOA + CpT(length(CpT),n+j);
    TotalSuspMSOA = TotalSuspMSOA + CpT(length(CpT),j);
    TotalVap = TotalVap + CvT(length(CpT),j);
end

TotalMSOA0 = sum(modelAtm.Pop1.Cp0)+sum(modelAtm.Pop2.Cp0);
Tau1 = modelAtm.DecayConstant*3600;

if modelAtm.PulseYN==1
    CheckMassBal = sum(modelAtm.Cv0)+modelAtm.ROG*modelAtm.EmitTime*sum(modelAtm.SOA.alphaProd)+TotalMSOA0-TotalPop2MSOA-TotalSuspMSOA-TotalVap;
else
    CheckMassBal = sum(modelAtm.Cv0)+modelAtm.Injection*(1-exp(-FinalTime/Tau1))*sum(modelAtm.SOA.alphaProd)+TotalMSOA0-TotalPop2MSOA-TotalSuspMSOA-TotalVap;
end

toler = 1e-7;
if abs(CheckMassBal) > 1e-7
    Error = 'Mass balance is not correct!';
else
    Error = 'NO mass balance error!';
end

CheckEqm(1) = (CpT(length(CpT),1)+CpT(length(CpT),n+1))/(CvT(length(CpT),1)+CpT(length(CpT),1)+CpT(length(CpT),1*n+1))-...
    1/(1+modelAtm.CStarBasis(1)/(TotalPop2MSOA+TotalSuspMSOA));
CheckEqm(2) = NaN;
CheckEqm(3) = (CpT(length(CpT),3)+CpT(length(CpT),n+3))/(CvT(length(CpT),3)+CpT(length(CpT),3)+CpT(length(CpT),1*n+3))-...
    1/(1+modelAtm.CStarBasis(3)/(TotalPop2MSOA+TotalSuspMSOA));

FracMassToSuspended = TotalSuspMSOA/(TotalSuspMSOA+TotalPop2MSOA);

%Calculate mole fractions of organics on particles--------------------------
for p = 1:TotalPop
   PopString = int2str(p);
   XCpT_1 = CpT(:,(p-1)*n+3)./(CpT(:,(p-1)*n+1)+CpT(:,(p-1)*n+3));
   XCpT_01 = CpT(:,(p-1)*n+1)./(CpT(:,(p-1)*n+1)+CpT(:,(p-1)*n+3));
  % eval(['Struct.P' PopString '.XCpT_1 = XCpT_1;']);
   eval(['modelAtm.Pop' PopString '.XCpT_1 = XCpT_1;']);
  % eval(['Struct.P' PopString '.XCpT_1 = XCpT_1;']);
   eval(['modelAtm.Pop' PopString '.XCpT_1 = XCpT_1;']);
end

 for i=1:length(Tagg)
     Cp1Wall(i) = 0;
     Cp01Wall(i) = 0;
     Cp_1Wall(i) = 0;
     Cp1_Wall(i) = 0;
     for j = 2:TotalPop
        Cp1Wall(i) = Cp1Wall(i) + CpT(i,4*(j-1)+3);
        Cp_1Wall(i) = Cp_1Wall(i) + CpT(i,4*(j-1)+2);
        Cp01Wall(i) = Cp01Wall(i) + CpT(i,4*(j-1)+1);
        Cp1_Wall(i) = Cp1_Wall(i) + CpT(i,4*(j-1)+4);
     end
     MSulfWall(i) = MSulfT(i,2);
     Cp1Sus(i) = CpT(i,3);
     Cp1_Sus(i) = CpT(i,4);
     Cp_1Sus(i) = CpT(i,2);
     Cp01Sus(i) = CpT(i,1);
     MSulfSus(i) = MSulfT(i,1);
 end

MassforPlot = [Cp01Wall; Cp1Wall; Cp01Sus; Cp1Sus; MSulfWall; MSulfSus];
MassforPlotAlpha = [Cp01Wall; Cp_1Wall; Cp1Wall; Cp1_Wall; Cp01Sus; Cp_1Sus; Cp1Sus; Cp1_Sus; MSulfWall; MSulfSus];



for j = 1:length(Tagg)
   TotalOrgMass = sum(CpT(j,1:modelAtm.NumBins));
   TotalMass(j) = TotalOrgMass+MSulfT(j,1);
   rho = (TotalOrgMass+MSulfT(j,1))/(MSulfT(j,1)/modelAtm.Sulf.rho+TotalOrgMass/modelAtm.SOA.rho);
   CondSinkBG(j) = UpdateBackgroundCS(TotalMass(j),DpT(j,1),rho);
   BG_MtoCS(j) = TotalMass(j)/CondSinkBG(j);
   
   
   TotalOrgMass = sum(CpT(j,5:2*modelAtm.NumBins));
   TotalMass(j) = TotalOrgMass + MSulfT(j,2);
   rho = (TotalOrgMass+MSulfT(j,2))/(MSulfT(j,2)/modelAtm.Sulf.rho+TotalOrgMass/modelAtm.SOA.rho);
   CondSinkNanoP(j) = UpdateBackgroundCS(TotalMass(j),DpT(j,2),rho);
   NanoP_MtoCS(j) = TotalMass(j)/CondSinkNanoP(j);
   
   
   
   
   
end

for j = 1:length(trackCondSink(:,1))
totalCondSink = trackCondSink(j,2)+trackCondSink(j,3);
   BG_PctCondSink(j) = trackCondSink(j,2)/totalCondSink;
   NP_PctCondSink(j) = trackCondSink(j,3)/totalCondSink;
   
   totalFlux = trackCondSink(j,10)+trackCondSink(j,11);
   BG_PctFlux(j) = trackCondSink(j,10)/totalFlux;
   NP_PctFlux(j) = trackCondSink(j,11)/totalFlux;
end



figure(78)
plot(trackCondSink(:,1),trackCondSink(:,4),trackCondSink(:,1),trackCondSink(:,5))
%plot(Tagg/3600,BG_MtoCS,Tagg/3600,NanoP_MtoCS)
%plot(
%DISPLAY FIGURES----------------------------------------------------
%CreateFigNumConc; 

CreateFig;
if modelAtm.AlphaPYN == 1 || modelAtm.AlphaPYNPop2 == 1 || modelAtm.AlphaPYNVap == 1
    CreateFigMassAlpha2;
    CreateMolFracFigAlpha;
else
    CreateFigMass;
    CreateMolFracFig;
end

if modelAtm.EmitBin ==1
   DispEmitBin = 1e-2;
elseif modelAtm.EmitBin==3
   DispEmitBin = 1e0;
end

if modelAtm.BGBin ==1
   DispBGBin = 1e-2;
elseif modelAtm.BGBin==3
   DispBGBin = 1e0;
end


table.ROG = modelAtm.ROG;
table.EmitTime = EmitTime/3600;
table.EmitBin = DispEmitBin;
table.BGBin = DispBGBin;
table.TotalSusp = TotalSusp;
table.TotalOnWall = TotalOnWall;
table.kwall = modelAtm.kwall;
table;



