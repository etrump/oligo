function [dCv dCp] = ParticleGrowth(Cv, Cp, CondSink, j, KelvinYN,ROG)

global modelAtm

%KelvinYN = 1; %for testing

%j is the population number
n=modelAtm.NumBins;
CStarBasis = modelAtm.CStarBasis;
alpha = modelAtm.SOA.alphaProd;


    
total_cov = 0;
for i=2:modelAtm.Pop
   CovString = int2str(i);
   eval(['total_cov = total_cov + modelAtm.Pop' CovString '.coverage;']);
end

CurPop = int2str(j);

eval(['Dp = modelAtm.Pop' CurPop '.Dp;'])

modelAtm.total_cov = total_cov;

%Consider aging of C* = 1 vapors
ResTime = modelAtm.AgingResTime*3600; %1/s
CvAging(3) = -1*Cv(3)*1/(ResTime);
CvAging(1) = -1*CvAging(3);
CvAging(2) = 0; 
CvAging(4) = 0; 
if modelAtm.AgingYN~=1
    CvAging = zeros(1,n); %No aging
end

for i=1:n
    if j==1 %suspended particles
        P(i) = alpha(i)*ROG;  %Production rate of species i (vapor), [=] ug/m3-s
    else
        P(i) = 0;              % Only produce vapors once
    end
%if j==2
%    Cp
%end
    if sum(Cp)<=0         %If nothing on the particle, set mol frac = 1
        MolFrac(i)=1;
    else
        MolFrac(i)=Cp(i)/(sum(Cp));  %Calculate mole fraction of organic i in particle phase
        %Cp
       % MolFrac(i)=Cp(i)/
    end
    
    if KelvinYN==1
        Kelvin(i) = KelvinTerm(j);
    else
        Kelvin(i) = 1;     %do not consider Kelvin effect       
    end
    

    Ceq(i) = Kelvin(i)*MolFrac(i)*CStarBasis(i);
   
    jString = int2str(j);
    eval(['modelAtm.Pop' jString '.Ceq = Ceq(i);']);
    QPhi(i)=1*CondSink*(Cv(i)-Kelvin(i)*MolFrac(i)*CStarBasis(i)); % calculte flux assuming no other limitations [=]ug/m3-s
    DriveForce(i) = Cv(i)-Ceq(i);
    eval(['modelAtm.Pop' jString '.DriveForce = DriveForce(i);']);
    
    tol = 1e-16;
    tol = 0;
    if(QPhi(i)>=0)  % Always allow organic flux toward bulk particles
        Phi(i)=QPhi(i);
        elseif (Cp(i)>abs(QPhi(i)))  % Allow flux away from particle if suffient mass on particle
            Phi(i)=QPhi(i);
            elseif (Cp(i)<=tol)  % When no particle-phase mass, nothing can flux away
                Phi(i)=0;
                else
                    Phi(i)=-1*Cp(i);  % But can allow all of particle-phase mass to flux away
    end
       
    %CvAging(i) = 0;
    
   if QPhi(i)>0 && QPhi(i)>Cv(i)
        QPhi(i) = Cv(i);
    end
    
    
    if (Phi(i)+Cp(i))<tol %%%%replaced 0
        dCv(i) = P(i)+CvAging(i);
        dCp(i) = 0+CvAging(i);
        dCp(i) = 0;  
    else
        dCv(i)=P(i)-Phi(i)+CvAging(i);
        dCp(i)=Phi(i)+CvAging(i);
        dCp(i) = Phi(i);
    end
    
      %Change in gas-phase concentration, or production minus flux to particles, [=] ug/m3-s
      %Change in particle-phase concentration, or flux to particle, [=] ug/m3-s
end
    



